from django.contrib import admin
from django.conf.urls import include, url
from . import views
#contain all functions and html
urlpatterns = [
    url('about$',views.about,name="about"),   
    url('saveTest$',views.saveTest,name="saveTest"),   
    url('showTest$',views.showTest,name="showTest"), 
    url('flipkart$',views.flipkart,name="flipkart"), 
    url('search$',views.search,name="search"),
    url('contact$',views.contact,name="contact"), 
    url('signup$',views.signup,name="signup"),
    url('showcrawldata$',views.showcrawldata,name="showcrawldata"),
    url('login$',views.login,name="login"),
    
    
    url('home$',views.home,name="home"),
    url('',views.index,name="index"), # landing / default page 
    
]
